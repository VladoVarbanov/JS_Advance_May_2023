class Garden {

}